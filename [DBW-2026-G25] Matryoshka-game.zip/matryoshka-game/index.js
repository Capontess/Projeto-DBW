import express from "express";
import path from 'path';
import { fileURLToPath } from 'url';
import mongoose from 'mongoose';
import session from 'express-session';
import { createServer } from 'http';
import { Server } from 'socket.io';
import gameRoutes from "./routes/gameRoutes.js";
import User from "./models/User.js"; // ✅ importar o modelo User
import Word from "./models/Word.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer);

// Ligação ao MongoDB
mongoose.connect('mongodb://127.0.0.1:27017/matrioskadbw')
    .then(() => console.log("Ligado ao MongoDB"))
    .catch(err => console.error("Erro MongoDB:", err));

app.set("view engine", "ejs");
app.use(express.static(path.join(__dirname, "public")));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Sessões
app.use(session({
    secret: 'segredo_matrioska',
    resave: false,
    saveUninitialized: false
}));

app.use("/", gameRoutes);

// --- Lógica de salas multiplayer ---
const salas = {};

io.on('connection', (socket) => {

   socket.on('entrarSala', async ({ salaId, nomeJogador, userId }) => {
    socket.join(salaId);

    if (!salas[salaId]) {
        // Escolhe palavra UMA vez quando a sala é criada
        const palavras = await Word.find();
        const jogoAleatorio = palavras[Math.floor(Math.random() * palavras.length)];
        salas[salaId] = { 
            jogadores: [], 
            palavras: {},
            jogo: jogoAleatorio
        };
    }

    salas[salaId].jogadores.push({ id: socket.id, nome: nomeJogador, userId });
    salas[salaId].palavras[socket.id] = undefined;

    io.to(salaId).emit('jogadoresNaSala', salas[salaId].jogadores);

    if (salas[salaId].jogadores.length === 2) {
        io.to(salaId).emit('iniciarJogo', {
            palavraMestra: salas[salaId].jogo.palavraMestra,
            subPalavrasValidas: salas[salaId].jogo.subPalavrasValidas
        });
    }
});

    socket.on('palavraSubmetida', ({ salaId, count }) => {
        socket.to(salaId).emit('adversarioAtualizou', { count });
    });

    // ✅ async para poder usar await na BD
    socket.on('jogoTerminado', async ({ salaId, score, userId }) => {
        const sala = salas[salaId];
        if (!sala) return;

        sala.palavras[socket.id] = score;

        const todosTerminaram = sala.jogadores.every(j => sala.palavras[j.id] !== undefined);

        if (todosTerminaram) {
            const [j1, j2] = sala.jogadores;
            const score1 = sala.palavras[j1.id];
            const score2 = sala.palavras[j2.id];
            const vencedor = score1 > score2 ? j1.nome
                           : score2 > score1 ? j2.nome
                           : 'Empate';

            // ✅ Atualiza a BD para os DOIS jogadores diretamente no servidor
            try {
                for (const jogador of [j1, j2]) {
                    const ganhou = vencedor === jogador.nome;
                    const empate = vencedor === 'Empate';

                    await User.findByIdAndUpdate(jogador.userId, {
                        $inc: {
                            'estatisticas.jogosJogados': 1,
                            'estatisticas.vitorias':  (ganhou || empate) ? 1 : 0,
                            'estatisticas.derrotas':  (!ganhou && !empate) ? 1 : 0
                        }
                    });
                }
                console.log('✅ Estatísticas guardadas para ambos os jogadores.');
            } catch (err) {
                console.error('❌ Erro ao guardar estatísticas:', err);
            }

            io.to(salaId).emit('resultadoFinal', {
                jogadores: [
                    { nome: j1.nome, score: score1 },
                    { nome: j2.nome, score: score2 }
                ],
                vencedor
            });

            delete salas[salaId];
        }
    });

    socket.on('disconnect', () => {
        for (const salaId in salas) {
            const sala = salas[salaId];
            const estavaNaSala = sala.jogadores.some(j => j.id === socket.id);
            if (!estavaNaSala) continue;

            sala.jogadores = sala.jogadores.filter(j => j.id !== socket.id);
            if (sala.jogadores.length === 0) delete salas[salaId];
            else socket.to(salaId).emit('adversarioSaiu');
        }
    });
});

httpServer.listen(3000, () => console.log("Servidor em http://localhost:3000"));