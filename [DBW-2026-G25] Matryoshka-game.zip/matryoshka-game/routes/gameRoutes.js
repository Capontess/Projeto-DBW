import express from 'express';
import * as ctrl from '../controllers/gameController.js';
import multer from 'multer';
import path from 'path';
const router = express.Router();

// ✅ Middleware de autenticação
function requireAuth(req, res, next) {
    if (!req.session.userId) {
        return res.redirect('/login');
    }
    next();
}

const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, 'public/images/'),
    filename: (req, file, cb) => {
        const uniqueName = req.session.userId + '-' + Date.now() + path.extname(file.originalname);
        cb(null, uniqueName);
    }
});
const upload = multer({ storage });

// Perfil
router.post('/perfil/update-foto', requireAuth, upload.single('profileImage'), ctrl.updateProfilePic);
router.post('/perfil/update-nome', requireAuth, ctrl.updateName);

// Rotas GET
router.get('/', ctrl.getMenu1);
router.get('/login', ctrl.getLogin);
router.get('/register', ctrl.getRegister);
router.get('/reset-password', ctrl.getResetPassword);
router.get('/menu', requireAuth, ctrl.getMenu2);          // ✅ protegida
router.get('/sobre', ctrl.getAbout);
router.get('/ajuda', ctrl.getSupport);
router.get('/perfil', requireAuth, ctrl.getProfile);      // ✅ protegida
router.get('/multiplayer', requireAuth, ctrl.getMultiplayer); // ✅ protegida
router.get('/singleplayer', requireAuth, ctrl.getSingleplayer); // ✅ protegida
router.get('/winner', requireAuth, ctrl.getWinner);       // ✅ protegida

// Rotas POST
router.post('/register', ctrl.postRegister);
router.post('/login', ctrl.postLogin);
router.post('/reset-password', ctrl.postResetPassword);
router.post('/update-name', requireAuth, ctrl.updateName);
router.post('/winner', requireAuth, ctrl.postWinnerData);

// ✅ Logout
router.get('/logout', (req, res) => {
    req.session.destroy(() => {
        res.redirect('/login');
    });
});

export default router;