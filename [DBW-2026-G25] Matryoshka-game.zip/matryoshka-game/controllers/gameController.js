import User from '../models/User.js';
import bcrypt from 'bcrypt';
import Word from '../models/Word.js';

// --- Páginas Estáticas ---
export const getMenu1 = (req, res) => res.render('index');
export const getLogin = (req, res) => res.render('login', { erro: null });
export const getRegister = (req, res) => res.render('register');
export const getResetPassword = (req, res) => res.render('reset-password', { erro: null });
export const getMenu2 = (req, res) => res.render('menu');

// --- Reset Password ---
export const postResetPassword = async (req, res) => {
    try {
        const { username, password, confirmPassword } = req.body;

        if (!username || !password)
            return res.render('reset-password', { erro: 'Preenche todos os campos.' });

        if (password !== confirmPassword)
            return res.render('reset-password', { erro: 'As passwords não coincidem.' });

        const user = await User.findOne({ username: username.trim() });
        if (!user)
            return res.render('reset-password', { erro: 'Username não encontrado.' });

        const hashedPassword = await bcrypt.hash(password, 10);
        await User.findByIdAndUpdate(user._id, { password: hashedPassword });

        res.redirect('/login');
    } catch (err) {
        res.render('reset-password', { erro: 'Erro ao alterar password.' });
    }
};

// --- Multiplayer ---
export const getMultiplayer = async (req, res) => {
    try {
        const user = await User.findById(req.session.userId);
        if (!user) return res.redirect('/login');
        const palavras = await Word.find();
        const jogoAleatorio = palavras[Math.floor(Math.random() * palavras.length)];
        res.render('multiplayer', { user, jogo: jogoAleatorio });
    } catch (err) {
        res.redirect('/login');
    }
};

// --- Lógica de Jogo e Vitória ---
export const postWinnerData = async (req, res) => {
    try {
        const { score, scoreBot, palavra, vencedor } = req.body;

        if (!req.session.userId)
            return res.status(401).json({ success: false, message: 'Sessão expirada.' });

        const user = await User.findById(req.session.userId);
        if (!user)
            return res.status(404).json({ success: false, message: 'Utilizador não encontrado.' });

        user.estatisticas.jogosJogados += 1;
        if (vencedor === 'jogador') {
            user.estatisticas.vitorias += 1;
        } else {
            user.estatisticas.derrotas += 1;
        }

        await user.save();
        res.status(200).json({ success: true });
    } catch (err) {
        console.error('Erro ao guardar stats:', err);
        res.status(500).json({ success: false });
    }
};

export const getWinner = async (req, res) => {
    try {
        if (!req.session.userId) return res.redirect('/login');
        const user = await User.findById(req.session.userId);
        if (!user) return res.redirect('/login');
        res.render('winner', { user });
    } catch (err) {
        res.redirect('/login');
    }
};

// --- Páginas com Header ---
export const getAbout = async (req, res) => {
    try {
        const user = await User.findById(req.session.userId);
        res.render('sobre', { user });
    } catch (err) {
        res.redirect('/login');
    }
};

export const getSupport = async (req, res) => {
    try {
        const user = await User.findById(req.session.userId);
        res.render('ajuda', { user });
    } catch (err) {
        res.redirect('/login');
    }
};

export const getSingleplayer = async (req, res) => {
    try {
        const user = await User.findById(req.session.userId);
        if (!user) return res.redirect('/login');
        const palavras = await Word.find();
        const jogoAleatorio = palavras[Math.floor(Math.random() * palavras.length)];
        res.render('singleplayer', { user, jogo: jogoAleatorio });
    } catch (err) {
        res.redirect('/login');
    }
};

// --- Perfil ---
export const getProfile = async (req, res) => {
    if (!req.session.userId) return res.redirect('/login');
    try {
        const user = await User.findById(req.session.userId);
        if (!user) return res.redirect('/login');
        res.render('perfil', { user });
    } catch (err) {
        res.status(500).send("Erro no perfil.");
    }
};

// --- Autenticação ---
export const postRegister = async (req, res) => {
    try {
        const { nome, email, username, password, confirmPassword } = req.body;
        if (password !== confirmPassword) return res.send("Passwords não coincidem.");

        const hashedPassword = await bcrypt.hash(password, 10);
        const novoUser = new User({
            nome, email, username, password: hashedPassword,
            profileImage: 'avatar1.png',
            estatisticas: { jogosJogados: 0, vitorias: 0, derrotas: 0 }
        });
        await novoUser.save();
        req.session.userId = novoUser._id;
        res.redirect('/menu');
    } catch (err) {
        res.status(500).send("Erro no registo.");
    }
};

export const postLogin = async (req, res) => {
    try {
        const { username, password } = req.body;
        const user = await User.findOne({ username });
        if (user && await bcrypt.compare(password, user.password)) {
            req.session.regenerate((err) => {
                if (err) return res.status(500).send("Erro na sessão.");
                req.session.userId = user._id;
                req.session.save((err) => {
                    if (err) return res.status(500).send("Erro ao guardar sessão.");
                    return res.redirect('/menu');
                });
            });
        } else {
            res.render('login', { erro: 'Username ou password incorretos.' });
        }
    } catch (err) {
        res.status(500).send("Erro no login.");
    }
};

// --- Atualizar Foto ---
export const updateProfilePic = async (req, res) => {
    try {
        if (!req.file)
            return res.status(400).json({ success: false, message: 'Nenhum ficheiro.' });

        const imagePath = req.file.filename;
        await User.findByIdAndUpdate(req.session.userId, { profileImage: imagePath });
        res.json({ success: true, imagePath });
    } catch (err) {
        console.error(err);
        res.status(500).json({ success: false, message: 'Erro ao atualizar foto.' });
    }
};

// --- Atualizar Nome ---
export const updateName = async (req, res) => {
    try {
        const { newName } = req.body;

        if (!newName || newName.trim() === '')
            return res.json({ success: false, message: 'Nome inválido.' });

        const existe = await User.findOne({ nome: newName.trim(), _id: { $ne: req.session.userId } });
        if (existe)
            return res.json({ success: false, message: 'Este nome já está em uso.' });

        const user = await User.findByIdAndUpdate(
            req.session.userId,
            { nome: newName.trim() },
            { new: true }
        );
        res.json({ success: true, nome: user.nome });
    } catch (err) {
        console.error(err);
        res.status(500).json({ success: false, message: 'Erro ao atualizar nome.' });
    }
};