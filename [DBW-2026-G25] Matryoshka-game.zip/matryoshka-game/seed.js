import mongoose from 'mongoose';
import Word from './models/Word.js';

const mongoURI = 'mongodb://127.0.0.1:27017/matrioskadbw';

const palavras = [
    { palavraMestra: "SOLIDARIEDADE", subPalavrasValidas: ["SOL","LIDA","IDA","IDADE","ARDE","DADE","ALI"] },
    { palavraMestra: "PASSAGEIRO", subPalavrasValidas: ["PASSA","ASA","AGE","EIRO","SAGE","PASSO","IRA"] },
    { palavraMestra: "TRABALHADOR", subPalavrasValidas: ["TRABALHO","LABOR","ALHO","DOR","HORA","OBRA","ABA"] },
    { palavraMestra: "MOVIMENTO", subPalavrasValidas: ["MOVE","MOVI","VENTO","MENTO","VIM","VIME","MENTE"] },
    { palavraMestra: "SABEDORIA", subPalavrasValidas: ["SABE","SABER","BEDO","DOR","DORA","ORIA","ABE"] },
    { palavraMestra: "LIBERDADE", subPalavrasValidas: ["LIBER","LIVRE","DADE","ERA","ERDE","LIBERA","BER"] },
    { palavraMestra: "DESCOBERTA", subPalavrasValidas: ["DESCOBRE","COBRE","BERTA","DESCO","ERTA","DES","COBR"] },
    { palavraMestra: "FELICIDADE", subPalavrasValidas: ["FELIZ","CIDADE","DADE","IDADE","IDA","FELIC","FELI"] },
    { palavraMestra: "TEMPESTADE", subPalavrasValidas: ["TEMPO","PESTE","ESTA","DADE","TESTA","TEMPE","ESTADA"] },
    { palavraMestra: "MARAVILHOSO", subPalavrasValidas: ["MARAVILHA","MARA","VILA","VILHO","OSO","AVIL","MARAV"] },
    { palavraMestra: "CONVERSACAO", subPalavrasValidas: ["CONVERSA","VERSA","VERSO","CONV","VERSAR","CONVER","SACAO"] },
    { palavraMestra: "IMAGINACAO", subPalavrasValidas: ["IMAGINA","IMAGEM","MAGIA","MAGO","ACAO","MAGI","IMAGIN"] },
    { palavraMestra: "TERRITORIO", subPalavrasValidas: ["TERRA","TERRI","ORIO","TORIO","TERRO","ERRO","TERRIT"] },
    { palavraMestra: "CARAVELA", subPalavrasValidas: ["CARA","VELA","RAVE","CAVA","CAVE","ARAVEL","ARA"] },
    { palavraMestra: "SAUDADE", subPalavrasValidas: ["SAUDA","DADE","UDA","SAUDAR","AUD","SAU","AUDA"] },
    { palavraMestra: "PESCADOR", subPalavrasValidas: ["PESCA","PESCAR","ESCA","CADOR","ADOR","DOR","PESCAD"] },
    { palavraMestra: "NAVEGADOR", subPalavrasValidas: ["NAVEGA","NAVE","VEGA","GADOR","ADOR","DOR","NAVEG"] },
    { palavraMestra: "FLORESTA", subPalavrasValidas: ["FLOR","FLORA","RESTA","ESTA","REST","FLORES","LORE"] },
    { palavraMestra: "BORBOLETA", subPalavrasValidas: ["BOLO","BOTA","BOLA","TELA","BOA","LETA","RETA"] },
    { palavraMestra: "MONTANHA", subPalavrasValidas: ["MONTA","MANTA","ANTA","MAO","TOM","MONT","NATO"] }
];

async function seedDB() {
    try {
        await mongoose.connect(mongoURI);
        console.log("Ligado ao MongoDB...");

        await Word.deleteMany({});
        console.log("Coleção limpa.");

        await Word.insertMany(palavras);
        console.log("✅ 20 palavras inseridas com sucesso!");

        await mongoose.connection.close();
        process.exit(0);
    } catch (erro) {
        console.error("❌ Erro ao inserir:", erro);
        process.exit(1);
    }
}

seedDB();