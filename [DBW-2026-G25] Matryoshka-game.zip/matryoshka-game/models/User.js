// Ficheiro: models/User.js
import mongoose from 'mongoose';

const userSchema = new mongoose.Schema({
    username: { type: String, required: true, unique: true },
    nome: { type: String, required: true },
    email: { type: String, required: true },
    password: { type: String, required: true },
    profileImage: { type: String, default: 'avatar1.png' }, 
    estatisticas: {
        jogosJogados: { type: Number, default: 0 },
        vitorias: { type: Number, default: 0 },
        derrotas: { type: Number, default: 0 }
    }
});
// Criamos o modelo baseado no esquema e exportamos
const User = mongoose.model('User', userSchema);
export default User;
