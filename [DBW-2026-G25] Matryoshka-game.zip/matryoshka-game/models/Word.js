// Ficheiro: models/Word.js
import mongoose from 'mongoose';

const wordSchema = new mongoose.Schema({
    palavraMestra: { type: String, required: true },
    subPalavrasValidas: [{ type: String }] // Uma lista (array) com as palavras corretas
});

export default mongoose.model('Word', wordSchema);