let tempoSegundos = 60;
const displayTimer = document.getElementById('timer');
const input = document.getElementById('inputPalavra');
const listaUI = document.getElementById('palavrasEncontradas');
const palavrasCertinhas = ["MAO", "TRIO", "RISO", "AMOR", "ROSA", "MATO"];
let encontradas = [];

const contagem = setInterval(() => {
    tempoSegundos--;
    let m = Math.floor(tempoSegundos / 60);
    let s = tempoSegundos % 60;
    displayTimer.innerText = `${m < 10 ? '0' : ''}${m}:${s < 10 ? '0' : ''}${s}`;

    if (tempoSegundos <= 0) {
        clearInterval(contagem);
        alert("Fim do tempo!");
        window.location.href = "/menu";
    }
}, 1000);

function validarPalavra() {
    const pal = input.value.toUpperCase().trim();
    
    if (palavrasCertinhas.includes(pal) && !encontradas.includes(pal)) {
        encontradas.push(pal);
        const item = document.createElement('li');
        item.innerText = pal;
        item.style.padding = "5px";
        item.style.borderBottom = "1px solid #999";
        listaUI.appendChild(item);
        input.value = "";

        if (encontradas.length === palavrasCertinhas.length) {
            window.location.href = "/winner";
        }
    } else {
        // Efeito visual de erro
        input.style.backgroundColor = "#ffcccc";
        setTimeout(() => input.style.backgroundColor = "white", 300);
    }
}