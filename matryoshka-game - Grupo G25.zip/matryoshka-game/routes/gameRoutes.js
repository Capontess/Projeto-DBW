import express from 'express';
import * as ctrl from '../controllers/gameController.js';

const router = express.Router();

// --- Rotas de Autenticação e Início ---
router.get('/', ctrl.getMenu1);
router.get('/login', ctrl.getLogin);
router.get('/register', ctrl.getRegister);
router.get('/reset-password', ctrl.getResetPassword);

// --- Rota do Menu Principal (Onde estão os botões brancos em cruz) ---
router.get('/menu', ctrl.getMenu2);

// --- Rotas das Páginas com a Barra Vermelha (Header) ---
// Estas rotas devem ser usadas nos href do teu Header
router.get('/sobre', ctrl.getAbout);
router.get('/ajuda', ctrl.getSupport);
router.get('/perfil', ctrl.getProfile);

// --- Rotas de Jogo ---
router.get('/multiplayer', ctrl.getMultiplayer);
router.get('/singleplayer', ctrl.getSingleplayer);
router.get('/winner', ctrl.getWinner);

export default router;