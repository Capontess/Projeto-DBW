export const gameData = {
    palavraMestra: "MATRIOSKA",
    subPalavrasValidas: ["MAO", "TRIO", "RISO", "AMOR", "ROSA", "MATO", "IRA", "MAIOR", "TOSA", "MORA"],
    ajuda: {
        email: "suporte@matrioskadbw.com",
        telefone: "(+351) 291 000 000"
    }
};