import express from "express";
import path from 'path';
import { fileURLToPath } from 'url';
import gameRoutes from "./routes/gameRoutes.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

app.set("view engine", "ejs");
app.use(express.static(path.join(__dirname, "public")));
app.use(express.urlencoded({ extended: true }));

app.use("/", gameRoutes);

app.listen(3000, () => {
    console.log("Servidor Matryoshka a correr em http://localhost:3000");
});