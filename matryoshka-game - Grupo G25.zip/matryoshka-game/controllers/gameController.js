export const getMenu1 = (req, res) => res.render('index'); // Ficheiro Menu1
export const getLogin = (req, res) => res.render('login');
export const getRegister = (req, res) => res.render('register');
export const getResetPassword = (req, res) => res.render('reset-password');
export const getMenu2 = (req, res) => res.render('menu'); // Ficheiro Menu2
export const getAbout = (req, res) => res.render('sobre');
export const getSupport = (req, res) => res.render('ajuda');
export const getProfile = (req, res) => res.render('perfil');
export const getMultiplayer = (req, res) => res.render('multiplayer');
export const getSingleplayer = (req, res) => res.render('singleplayer');
export const getWinner = (req, res) => res.render('winner');